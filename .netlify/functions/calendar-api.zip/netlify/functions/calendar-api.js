"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var calendar_api_exports = {};
__export(calendar_api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(calendar_api_exports);
var import_https = __toESM(require("https"), 1);
const handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { timeMin, timeMax, maxResults = "50" } = event.queryStringParameters || {};
    if (!process.env.GOOGLE_API_KEY || !process.env.CALENDAR_ID) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: "Missing environment variables. Please set GOOGLE_API_KEY and CALENDAR_ID"
        })
      };
    }
    const baseUrl = "https://www.googleapis.com/calendar/v3/calendars";
    const calendarId = encodeURIComponent(process.env.CALENDAR_ID);
    const apiKey = process.env.GOOGLE_API_KEY;
    const params = new URLSearchParams({
      key: apiKey,
      orderBy: "startTime",
      singleEvents: "true",
      maxResults
    });
    if (timeMin) {
      params.append("timeMin", timeMin);
    }
    if (timeMax) {
      params.append("timeMax", timeMax);
    }
    const apiUrl = `${baseUrl}/${calendarId}/events?${params.toString()}`;
    const data = await new Promise((resolve, reject) => {
      import_https.default.get(apiUrl, (res) => {
        let body = "";
        res.on("data", (chunk) => {
          body += chunk;
        });
        res.on("end", () => {
          try {
            const parsed = JSON.parse(body);
            resolve(parsed);
          } catch (error) {
            reject(new Error("Failed to parse Google Calendar response"));
          }
        });
      }).on("error", (error) => {
        reject(error);
      });
    });
    if (data.error) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: `Google Calendar API error: ${data.error.message}`
        })
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(data)
    };
  } catch (error) {
    console.error("Calendar API error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Failed to fetch calendar events",
        details: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
